package com.example.hw6;

import java.util.SplittableRandom;

public class Food
{
    private String foodname;

    private String foodDescription;

    public Food(String foodname, String foodDescription) {
        this.foodname = foodname;
        this.foodDescription= foodDescription;
    }

    public String getFoodname(){
        return foodname;
    }

    public String getFoodDescription(){return foodDescription;}

    public void setFoodname(String foodname){
        this.foodname= foodname;
    }
}
