//Kevin He//
package com.example.hw6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Food> foodList;
    private RecyclerView recyclerView;
    private recyclerAdapter.RecyclerViewClickListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView= findViewById(R.id.recyclerView);
        foodList=new ArrayList<>();

        setFoodInfo();
        setAdapter();
    }

    private void setAdapter() {
        setOnClickListner();
        recyclerAdapter adapter = new recyclerAdapter(foodList,listener);
        RecyclerView.LayoutManager layoutManager= new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void setOnClickListner() {
        listener = new recyclerAdapter.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {
                Intent intent= new Intent(getApplicationContext(),ProfileActivity.class);
                intent.putExtra("foodname",foodList.get(position).getFoodname());
                startActivity(intent);
            }
        };
    }

    private void setFoodInfo() {
        foodList.add(new Food("Mexi-Chicken Avocado Cups","Ten minutes and a handful of ingredients are all you need to make this healthy Mexican-inspired meal. " +
                "The recipe calls for canned chicken; some cooks have also had success with rotisserie chicken from the grocery store. " +
                "The buttery avocado bowl came together with the chicken cilantro chili powder and lime to make the perfect nutritional meal, says bd.weld. Be sure to keep the chicken moist so you don't have dry tasting chicken"));
        foodList.add(new Food("Microwave Chicken Teriyaki","Here's a super-quick teriyaki recipe made with soy sauce, ketchup, garlic powder, and a little sugar. A perfect partner for leftover rice. " +
                "This chicken can be served over rice, as a wrap, on a bun or with some added veggies as a quick and easy stir fry, says LROHNER."));
        foodList.add(new Food("Turkey-Pesto Toasterdilla","Spread prepared pesto on a flour tortilla, add layers of mozzarella string cheese and sliced deli turkey, fold up the tortilla and place into a toaster. " +
                "Toaster quesadillas are all the rage right now and are simple to make once you get the hang of it, says Soup Loving Nicole. The key is to make sure not to add too much to them. They need to be as flat as possible so that they do not get stuck but move freely in and out of the toaster slots."));
        foodList.add(new Food("Roasted Shrimp","This is a great, simple and fast way to cook shrimp that can go with anything! says Holly Van Lom. I've served it over linguine, with orzo and cream sauce, accompanying a steak, or alone as an appetizer -- the possibilities are endless!"));
        foodList.add(new Food("Quesadillas de Flor de Calabaza","\"These quesadillas de flor de calabaza are very popular in Mexico,\" says Yoly. \"The bacon grease gives the quesadillas another level of tastiness plus they crisp up beautifully. If bacon grease is unavailable, feel free to use lard, oil, or butter.\" To make these vegetarian, swap in a veggie oil for the bacon grease. No Manchego cheese? Mozzarella's a good substitute."));
        foodList.add(new Food("Tuna Lime Tostadas","\"White albacore tuna, onion, and corn are mixed with the flavors of lime, cilantro, and piquant hot sauce,\" says KMOUSE. \"Serve on a tostada or in a taco shell! This refreshing recipe is great for a hot summer day!\""));
        foodList.add(new Food("Burrito-Style Hot Dog Roll-Ups","Cooked hot dogs and slices of American cheese are wrapped up in tortillas for \"a fun twist on the usual dog, and great for a grab-and-go meal,\" says Mackenzie. \"Try different flavored tortillas for other delicious twists!\""));
        foodList.add(new Food("Simply Seared Scallops","\"This simple recipe uses minimal ingredients in order to highlight the delicious flavor of the sea scallop!\" says Stephanie Karek. \"Garnish with a drizzle of balsamic and chopped fresh basil.\""));
        foodList.add(new Food("Baked Tofu Spinach Wrap","You'll start by microwaving slices of hickory-flavor baked tofu and shredded Cheddar. Next you'll add fresh baby spinach, grated Parmesan, and Ranch dressing and wrap it all up. Some reviewers recommend warming the tortillas in a hot skillet for a few seconds on each side to keep them from breaking. \"Quick, simple and tasty!\" says VIKIM."));
        foodList.add(new Food( "Dorm Room Cheesy Tuna and Noodles","\"Cheap, easy, cheesy tuna and noodles for college students on a shoe string budget,\" says JCURPHY. \"If you really wanna dress it up, you can add thinly sliced almonds or sunflower seeds for more flavor and texture.\""));
    }

}